import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Server {
    private static List<Movie> movies;
    private static Lock lock = new ReentrantLock();

    public static void main(String[] args) {
        movies = createMovieList();

        try {
            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("Servidor escuchando en el puerto 12345...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Cliente conectado desde " + clientSocket.getInetAddress().getHostAddress());

                ClientHandler clientHandler = new ClientHandler(clientSocket, movies);
                new Thread(clientHandler).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static List<Movie> createMovieList() {
        List<Movie> movies = new ArrayList<>();
        movies.add(new Movie(1, "Pelicula1", "Director1", 10.0));
        movies.add(new Movie(2, "Pelicula2", "Director1", 15.0));
        movies.add(new Movie(3, "Pelicula3", "Director3", 20.0));
        movies.add(new Movie(4, "Pelicula4", "Director4", 25.0));
        movies.add(new Movie(5, "Pelicula5", "Director5", 30.0));
        return movies;
    }

    public static void addMovie(Movie movie) {
        movies.add(movie);
    }
}